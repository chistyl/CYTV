CYTV R57 built-in wallpaper assets
wallpaper_theme_01_message_bottle.jpg	1672x941	327147 bytes
wallpaper_theme_02_mountain_town.jpg	1672x941	582246 bytes
wallpaper_theme_03_platform_934.jpg	1672x941	395244 bytes
wallpaper_theme_04_meteor_shower.jpg	1672x941	294266 bytes
wallpaper_theme_05_fireflies.jpg	1672x941	231784 bytes
wallpaper_theme_06_abu_fish.jpg	1672x941	408699 bytes
wallpaper_theme_07_hamster_heart.jpg	1672x941	396646 bytes
wallpaper_theme_08_campfire.jpg	1672x941	374212 bytes
wallpaper_theme_09_winter_dog.jpg	1672x941	461302 bytes
All nine source images are JPEG, 1672x941, approximately 16:9.
